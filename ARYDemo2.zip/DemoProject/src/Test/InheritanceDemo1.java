package Test;

class Parent {
	protected int x;
	protected int y;
	
	public Parent() {
		System.out.println("Hi! This is Parent Constructor...");
	}
	public Parent(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public void showParent() {
		System.out.println("Hi! This is Parent Show() Method...");
	}
}

class Child extends Parent {
	private int z;
	
	public Child() {
		super();
		System.out.println("Hi! This is Child Constructor...");
	}
	public Child(int x, int y, int z) {
		super(x, y);
		this.z = z;		
		System.out.println("Hi! This is Child Constructor...");
	}
	public void showChild() {
		System.out.println("Hi! This is Child  Show() Method...");
	}
	
	public void sum() {
		System.out.println("The Sum is : " + (x + y));
	}
}

public class InheritanceDemo1 {
	public static void main(String[] args) {
		Child child = new Child();
		child.showParent();
		child.showChild(); 
		System.out.println();
		
		Child child2 = new Child(10,20,30);
		child2.sum();
	}
}
