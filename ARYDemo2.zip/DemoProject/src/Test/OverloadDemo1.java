package Test;

/*
Polymorphism: The ability of an object to behave in multiple forms

2 types:- Compiletime and Runtime

Compiletime:- 
If a method call binds with method defination at compiletime.
To implement we need method overloading concept.

Method Overloading:-
Writing multiple methods with same name but difference in parameters in a class.

*/


class Maths {
	public void sum(int x, int y) {
		System.out.println("The sum is : " + (x + y));
	}
	public void sum(double x, double y) {
		System.out.println("The sum is : " + (x + y));
	}
	public void sum(int x, int y, int z) {
		System.out.println("The sum is : " + (x + y + z));
	}
}

public class OverloadDemo1 {
	public static void main(String[] args) {
		Maths maths = new Maths();
		maths.sum(10, 20);
		maths.sum(10.2, 20.5);
		maths.sum(10, 20, 30);
	}
}
