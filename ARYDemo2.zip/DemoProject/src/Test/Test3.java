package Test;

public class Test3 {

	public static int[] Solution(int N) { // N = 12
		int[] res = new int[2]; // 2 ,6
		int a = 1;
		for (int i = 2; i < 50000; i++) {
			a = N - i;
			if ((i + "").contains("0") || (a + "").contains("0")) {
				continue;
			} else {
				res[0] = a;
				res[1] = i;
			}
			return res;
		}

		return res;
	}

	public static void main(String[] args) {

		for (int i : Solution(200)) {
			System.out.print(i + "   ");
		}
	}

}
