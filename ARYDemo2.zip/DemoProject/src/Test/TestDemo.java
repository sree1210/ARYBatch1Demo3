package Test;

public class TestDemo {

	public static void main(String[] args) {
		System.out.println("Successfully Executed...");
	}
}