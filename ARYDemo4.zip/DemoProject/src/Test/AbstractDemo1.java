package Test;

/*
Abstract Class:-
An abstract class is the class which contains atleast one abstract method.

Abstract method:-
If a method does not contains body it is called abstract method.

Rules:-
-An Abstract method and class must be declared with the keyword abstract
-It can have abstract and non-abstract (concrete) methods
-It cannot create object, but it can create reference variable

*/

abstract class Maths1 {
	public void sum(int a, int b) {
		System.out.println("The sum is : " + (a + b));
	}
	
	abstract public void sub(int a, int b);
	abstract public void mul(int a, int b);
}

class Calculate extends Maths1 {

	@Override
	public void sub(int a, int b) {
		System.out.println("The sub is : " + (a - b));
	}	
	
	public void mul(int a, int b) {
		System.out.println("The mul is : " + (a * b));
	}	
}

public class AbstractDemo1 {
	public static void main(String[] args) {
		Calculate calculate = new Calculate();
		calculate.sum(10, 5);
		calculate.sub(10, 5);
		calculate.mul(10, 5);
		System.out.println();
		
		Maths1 maths1 = new Calculate();
		maths1.sum(10, 5);
		maths1.sub(10, 5);
		maths1.mul(10, 5);
		
	}
}
