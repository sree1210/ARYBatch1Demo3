package Test;

public class EmployeeDemo1 {

	public static void main(String[] args) {
		FullTimeEmployee fullTimeEmployee = new FullTimeEmployee(1, "Sachin", "Tendulkar", 5000, 200);
		fullTimeEmployee.showDetails();
		System.out.println();
		
		PartTimeEmployee partTimeEmployee = new PartTimeEmployee(2, "MS", "Dhoni", 100, 200);
		partTimeEmployee.showDetails();
	}
}
