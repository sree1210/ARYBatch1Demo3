package Test;

class Parent1 {
	public void show() {
		System.out.println("Hi! this parent show...");
	}
}

class Child1 extends Parent1 {
	public void show() {
		System.out.println("Hi! this child show...");
	}
}

public class OverridingDemo1 {
	public static void main(String[] args) {	
		Child1 child = new Child1();
		child.show();
	}
}
