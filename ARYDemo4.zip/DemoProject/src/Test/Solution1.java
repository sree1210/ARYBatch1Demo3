package Test;

class Employee1 {
	protected int id;
	protected String firstName;
	protected String lastName;
	
	public Employee1() {
		super();
	}

	public Employee1(int id, String firstName, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}	
}

class FullTimeEmployee1 extends Employee1 {
	private double basic;
	private double bonus;
	
	public FullTimeEmployee1() {
		super();
	}

	public FullTimeEmployee1(int id, String firstName, String lastName, double basic, double bonus) {
		super(id, firstName, lastName);
		this.basic = basic;
		this.bonus = bonus;
	}	
	
	public double computeSalary() {
		return basic + bonus;
	}
	
	public String getFullName() {
		return firstName + " " + lastName;
	}
	
	public void sendMessage() {
		System.out.println("Salary Added to Account....");
	}
	
	public void showDetails() {
		System.out.println("Id           : " + id);
		System.out.println("Full Name    : " + getFullName());
		System.out.println("Gross Salary : " + computeSalary());
	}
}

class PartTimeEmployee1 extends Employee1 {
	private int hourWorked;
	private double amountPerHour;
	
	public PartTimeEmployee1() {
		super();
	}
		
	public PartTimeEmployee1(int id, String firstName, String lastName, int hourWorked, double amountPerHour) {
		super(id, firstName, lastName);
		this.hourWorked = hourWorked;
		this.amountPerHour = amountPerHour;
	}
	
	public double computeSalary() {
		return hourWorked * amountPerHour;
	}
	
	public String getFullName() {
		return firstName + " " + lastName;
	}
	
	public void sendMessage() {
		System.out.println("Salary Added to Account....");
	}
	
	public void showDetails() {
		System.out.println("Id           : " + id);
		System.out.println("Full Name    : " + getFullName());
		System.out.println("Gross Salary : " + computeSalary());
	}
}

public class Solution1 {
	public static void main(String[] args) {
		FullTimeEmployee fullTimeEmployee = new FullTimeEmployee(1, "Sachin", "Tendulkar", 5000, 200);
		fullTimeEmployee.showDetails();
		System.out.println();
		
		PartTimeEmployee partTimeEmployee = new PartTimeEmployee(2, "MS", "Dhoni", 100, 200);
		partTimeEmployee.showDetails();
	}
}
