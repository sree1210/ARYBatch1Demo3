package Test;

import java.util.Arrays;

public class Test {

	public static boolean checkZero(long num) {
		
			while(num > 0) {			
				if(num % 10 == 0) {
					return false;
				}				
				num = num / 10;
			}		
		return true;
	}

	public static String getResult(long range) {
		long i;
		long j;
		long sum;
		String result = "";

		for(i=2; i<range-1; i++) {
			for(j=i+1; j<range; j++) {

				sum = i + j;

				if(sum == range) {

					if(checkZero(i) && checkZero(j)) {

						if(result.equals("")) {
							result = "[" + i + ", " + j + "]";
						} else {
							result = result + ", [" + i + ", " + j + "]";
						}
					}
				}
			}
		}

		return result;		
	}

	public static void main(String[] args) {
		System.out.println(getResult(200));
	}

}
