package Test;

public class Test2 {

	public static int sumOfIndividualDigits(int num) {
		int sum = 0;

		while(num > 0) {
			sum += num % 10;
			num = num / 10;
		}
		return sum;
	}


	public static int findDigit(int num) {
		int i = num+1;
		int mainNumber = sumOfIndividualDigits(num) * 2;
		int result;

		if(num <= 500) {
			while(true) {
				result = sumOfIndividualDigits(i);
				if(result == mainNumber) {
					return i;
				}			
				i++;
			} 
		}
		return 0;
	}

	public static void main(String[] args) {
		System.out.println(findDigit(14));
		System.out.println(findDigit(10));
		System.out.println(findDigit(99));
		System.out.println(findDigit(600));
	}

}
